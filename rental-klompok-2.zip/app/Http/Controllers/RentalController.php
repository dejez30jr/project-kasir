<?php

namespace App\Http\Controllers;

use App\Models\Rental;
use Illuminate\Http\Request;

class RentalController extends Controller
{
    public function index()
    {
        return view('form');
    }

    public function store(Request $request)
    {
        // Validasi input
        $validated = $request->validate([
            'nama' => 'required|string|max:100',
            'jenis_ps' => 'required|in:PS3,PS4,PS5',
            'jam_mulai' => 'required|date_format:H:i',
            'jam_selesai' => 'required|date_format:H:i|after:jam_mulai',
            'total_bayar' => 'required|numeric|min:10000',
        ]);

        // Simpan data ke database
        Rental::create($validated);

        return redirect()->route('table.data')->with('success', 'Data rental berhasil disimpan!');
    }

    public function show()
    {
        $data_rental = Rental::all();
        return view('table-data', compact('data_rental'));
    }

    public function destroy($id)
    {
        $rental = Rental::findOrFail($id);
        $rental->delete();

        return redirect()->route('table.data')->with('success', 'Data rental berhasil dihapus!');
    }
}
