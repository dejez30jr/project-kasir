<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RentalController;

Route::get('/form', [RentalController::class,'index'])->name('show.form');
Route::post('/form', [RentalController::class, 'store'])->name('form.submit');

Route::get('/', [RentalController::class, 'show'])->name('table.data');
Route::get('/posts/{id}', [RentalController::class, 'show'])->name('rental.edit');
Route::delete('/table-data/{id}', [RentalController::class, 'destroy'])->name('rental.destroy');

